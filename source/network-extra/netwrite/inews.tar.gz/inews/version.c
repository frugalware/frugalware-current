/*
 * Provide the version number of this release.
 * Fixed many bugs, this version tested on Linux-1.1.0.x
 * Added the fix for users poll with * rejected. 9411212
 */

char	nntp_version[] = "1.5.11t* [Linux-1.1] (12 December 1994)";
